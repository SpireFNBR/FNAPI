import tkinter as tk
from tkinter import messagebox, simpledialog, font
import requests
from io import BytesIO
from PIL import Image, ImageTk
import re
from difflib import get_close_matches

#OPEN WITH THE PYTHON INTERPRETER :)

class FNAPIApp:
    def __init__(self, root):
        self.root = root
        self.root.title("FNAPI")
        self.root.geometry("800x500")
        self.root.configure(bg="#87CEEB")  

        
        self.root.iconphoto(False, tk.PhotoImage(file="logo.png"))

        
        self.sidebar = tk.Frame(self.root, width=250, bg="#007BFF")
        self.sidebar.pack(side=tk.LEFT, fill=tk.Y)

        
        self.content_frame = tk.Frame(self.root, bg="#87CEEB")
        self.content_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        
        self.title_label = tk.Label(self.sidebar, text="FNAPI", bg="#007BFF", fg="white", font=("HeadingNow-86BoldItalic", 16))
        self.title_label.pack(pady=10)

        
        self.shop_button = tk.Button(self.sidebar, text="SHOP SECTIONS", command=self.load_shop_sections, bg="#0056b3", fg="white", font=("HeadingNow-86BoldItalic", 12))
        self.shop_button.pack(pady=10)
        
        self.aes_button = tk.Button(self.sidebar, text="AES", command=self.load_aes_sections, bg="#0056b3", fg="white", font=("HeadingNow-86BoldItalic", 12))
        self.aes_button.pack(pady=10)

        self.playlist_button = tk.Button(self.sidebar, text="PLAYLIST", command=self.load_playlist, bg="#0056b3", fg="white", font=("HeadingNow-86BoldItalic", 12))
        self.playlist_button.pack(pady=10)

        
        self.news_button = tk.Button(self.sidebar, text="NEWS", command=self.load_news, bg="#0056b3", fg="white", font=("HeadingNow-86BoldItalic", 12))
        self.news_button.pack(pady=10)

        
        self.credits_button = tk.Button(self.sidebar, text="CREDITS", command=self.show_credits, bg="#0056b3", fg="white", font=("HeadingNow-86BoldItalic", 12))
        self.credits_button.pack(pady=10)

        
        self.content_text = tk.Text(self.content_frame, wrap=tk.WORD, bg="white", fg="black", font=("HeadingNow-86BoldItalic", 10))
        self.content_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        
        self.search_entry = tk.Entry(self.content_frame, font=("HeadingNow-86BoldItalic", 10))
        self.search_entry.pack(pady=10, padx=10, fill=tk.X)

        self.search_button = tk.Button(self.content_frame, text="Search", command=self.search_text, bg="#007BFF", fg="white")
        self.search_button.pack(pady=5)

        
        self.follow_label = tk.Label(self.sidebar, text="FOLLOW @SPIREFNBR", bg="red", fg="white", font=("HeadingNow-86BoldItalic", 10))
        self.follow_label.pack(side=tk.BOTTOM, fill=tk.X)

        self.get_username()

    def get_username(self):
        self.username = simpledialog.askstring("Username", "Enter your username:")
        if self.username:
            self.content_text.insert(tk.END, f"Hello, {self.username}!\n\n")
            self.content_text.insert(tk.END, "Made by @SpireFNBR https://x.com/SpireFNBR\n\n")

    def search_text(self):
        query = self.search_entry.get()
        if query:
            self.content_text.tag_remove("highlight", "1.0", tk.END)
            start_idx = "1.0"
            found = False
            while True:
                start_idx = self.content_text.search(query, start_idx, nocase=1, stopindex=tk.END)
                if not start_idx:
                    break
                end_idx = f"{start_idx}+{len(query)}c"
                self.content_text.tag_add("highlight", start_idx, end_idx)
                self.content_text.tag_config("highlight", background="yellow")
                start_idx = end_idx
                found = True

            # Si no se encontró ninguna coincidencia exacta, buscar coincidencias aproximadas
            if not found:
                all_text = self.content_text.get("1.0", tk.END)
                words = all_text.split()
                close_matches = get_close_matches(query, words)
                if close_matches:
                    messagebox.showinfo("Result", f"No exact matches found for '{query}'. Showing close matches for '{close_matches[0]}'")
                    self.search_entry.delete(0, tk.END)
                    self.search_entry.insert(0, close_matches[0])
                    self.search_text()
                else:
                    messagebox.showinfo("Result", f"No results found for '{query}'")

    def load_shop_sections(self):
        url = "https://fortnitecontent-website-prod07.ol.epicgames.com/content/api/pages/fortnite-game/mp-item-shop?lang=en"
        self.load_content(url, "shop_sections.txt", "Shop Sections")

    def load_aes_sections(self):
        url = "https://fortnitecentral.genxgames.gg/api/v1/aes"
        self.load_content(url, "aes_sections.txt", "AES Sections")

    def load_playlist(self):
        url = "https://fortnite-api.com/v1/playlists"
        try:
            response = requests.get(url)
            response.raise_for_status()
            data = response.json()

    
            self.content_text.delete(1.0, tk.END)
            self.content_text.insert(tk.END, "Playlists:\n\n")
            for item in data['data']:
                self.content_text.insert(tk.END, f"Name: {item['name']}\n", "bold")
                self.content_text.insert(tk.END, f"ID: {item['id']}\n")
                self.content_text.insert(tk.END, f"Description: {item.get('description', 'N/A')}\n")
                self.content_text.insert(tk.END, f"Game Type: {item.get('gameType', 'N/A')}\n\n")
            self.content_text.tag_config("bold", font=("HeadingNow-86BoldItalic", 10, "bold"))
            
            with open("playlist.txt", "w") as file:
                file.write(str(data))

            messagebox.showinfo("Success", "Playlist loaded and saved to 'playlist.txt'")
        except Exception as e:
            messagebox.showerror("Error", f"Error loading playlist: {e}")

    def load_news(self):
        url = "https://fortnite-api.com/v2/news"
        self.load_content(url, "news.txt", "News")

    def load_content(self, url, filename, title):
        try:
            response = requests.get(url)
            response.raise_for_status()
            data = response.text
            self.content_text.delete(1.0, tk.END)
            self.content_text.insert(tk.END, f"{title}:\n\n{data}")
            with open(filename, "w") as file:
                file.write(data)
            messagebox.showinfo("Success", f"{title} loaded and saved to '{filename}'")
        except Exception as e:
            messagebox.showerror("Error", f"Error loading {title}: {e}")

    def show_credits(self):
        self.content_text.delete(1.0, tk.END)
        credits_text = (
            "Credits:\n\n"
            "Developer: @SpireFNBR\n"
            "Twitter: https://x.com/SpireFNBR\n\n"
            "Special thanks to Fortnite API providers for their data services.\n\n"
            "API Endpoints:\n"
            "AES: https://fortnitecentral.genxgames.gg/api/v1/aes\n"
            "SHOP: https://fortnitecontent-website-prod07.ol.epicgames.com/content/api/pages/fortnite-game/mp-item-shop?lang=en\n"
            "MAP: https://fortnite-api.com/v1/map\n"
            "NEWS: https://fortnite-api.com/v2/news\n"
            "PLAYLIST: https://fortnite-api.com/v1/playlists\n"
        )
        self.content_text.insert(tk.END, credits_text)


if __name__ == "__main__":
    root = tk.Tk()
    app = FNAPIApp(root)
    root.mainloop()

    
